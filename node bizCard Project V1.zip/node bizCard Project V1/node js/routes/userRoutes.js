import express from 'express';
import userController from '../controllers/userController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

router.post('/register', userController.registerUser); // Free fo rallregister
router.post('/login', userController.loginUser); // Free for alllogin
router.get('/', auth(true, false), userController.getAllUsers); // Admin only
router.get('/:id', auth(false, true), userController.getUserById); // me or Admin
router.put('/:id', auth(false, true), userController.updateUser); // Registered user 
router.patch('/:id', auth(false, true), userController.patchUser); // Registered user 
router.delete('/:id', auth(false, true), userController.deleteUser); // me or Adminf

export default router;
